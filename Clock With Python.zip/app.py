import eel

eel.init('web')

eel.start('index.html', size=(450, 210))